<?php
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Http\Controllers\Controller;
use App\Models\User;

class UsersController extends Controller
{
    public function login(Request $request) {
        if (!Auth::attempts(['email'=>$request->email,'password'=>$request->password])){
            return response()-json(['error'=>'invalid info']);
        }

        $user - User::where('email', $request->email)->select('id','name','email')->first();
        return response()->json(['user'->$user->getAttributes()]);

    
    }

    public function users(Request $request) {
        $users = User::select('id','name','email')->get()->toArray();
        return response()->json(['users'=>$users]);
    }
    
    public function logout(Request $request) {}
}