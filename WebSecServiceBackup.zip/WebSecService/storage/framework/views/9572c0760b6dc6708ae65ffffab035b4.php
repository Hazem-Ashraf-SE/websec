<?php $__env->startSection('title', 'My Favorite Products'); ?>
<?php $__env->startSection('content'); ?>
<div class="row mt-2">
    <div class="col col-10">
        <h1>My Favorite Products</h1>
    </div>
    <div class="col col-2">
        <a href="<?php echo e(route('products_list')); ?>" class="btn btn-primary form-control">Back to Products</a>
    </div>
</div>

<?php if(auth()->user()->hasRole('Customer')): ?>
    <div class="alert alert-info">
        Your current credit: $<?php echo e(number_format(auth()->user()->credit, 2)); ?>

    </div>
<?php endif; ?>

<?php if($favorites->isEmpty()): ?>
    <div class="alert alert-warning mt-3">
        You don't have any favorite products yet. Browse the <a href="<?php echo e(route('products_list')); ?>">products page</a> to add some!
    </div>
<?php endif; ?>

<?php $__currentLoopData = $favorites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="card mt-2">
        <div class="card-body">
            <div class="row">
                <div class="col col-sm-12 col-lg-4">
                    <?php if($product->photo): ?>
                        <?php
                            $photoPath = $product->photo;
                            $imageUrl = asset('uploads/' . $photoPath);
                        ?>
                        <img src="<?php echo e($imageUrl); ?>" class="img-thumbnail" alt="<?php echo e($product->name); ?>" width="100%" onerror="this.onerror=null; this.src='<?php echo e(asset('images/default-product.jpg')); ?>';">
                    <?php else: ?>
                        <img src="<?php echo e(asset('images/default-product.jpg')); ?>" class="img-thumbnail" alt="<?php echo e($product->name); ?>" width="100%">
                    <?php endif; ?>
                </div>
                <div class="col col-sm-12 col-lg-8 mt-3">
                    <div class="row mb-2">
                        <div class="col-8">
                            <h3><?php echo e($product->name); ?></h3>
                        </div>
                        <div class="col col-4">
                            <button class="btn btn-danger form-control remove-favorite" data-product-id="<?php echo e($product->id); ?>">
                                <i class="fas fa-heart-broken"></i> Remove from Favorites
                            </button>
                        </div>
                    </div>

                    <table class="table table-striped">
                        <tr><th width="20%">Name</th><td><?php echo e($product->name); ?></td></tr>
                        <tr><th>Model</th><td><?php echo e($product->model); ?></td></tr>
                        <tr><th>Code</th><td><?php echo e($product->code); ?></td></tr>
                        <tr><th>Price</th><td>$<?php echo e(number_format($product->price, 2)); ?></td></tr>
                        <tr>
                            <th>Quantity</th>
                            <td><?php echo e($product->quantity); ?></td>
                        </tr>
                        <tr>
                            <th>In Stock</th>
                            <td>
                                <?php if($product->quantity > 0): ?>
                                    <?php if(auth()->user()->credit >= $product->price): ?>
                                        <form action="<?php echo e(route('products.buy', $product->id)); ?>" method="POST" style="margin-top: 5px;">
                                            <?php echo csrf_field(); ?>
                                            <button type="submit" class="btn btn-success">Buy Now</button>
                                        </form>
                                    <?php else: ?>
                                        <button class="btn btn-danger" disabled title="Insufficient credit. You need $<?php echo e(number_format($product->price - auth()->user()->credit, 2)); ?> more.">
                                            Insufficient Credit
                                        </button>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <button class="btn btn-secondary" disabled>Out of Stock</button>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <tr><th>Description</th><td><?php echo e($product->description); ?></td></tr>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    $(document).ready(function() {
        // Set up CSRF token for all AJAX requests
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
            }
        });
        
        // Handle remove from favorites
        $('.remove-favorite').on('click', function() {
            const productId = $(this).data('product-id');
            const card = $(this).closest('.card');
            
            $.ajax({
                url: `<?php echo e(url('favorites/toggle')); ?>/${productId}`,
                type: 'POST',
                success: function(response) {
                    if (response.status === 'removed') {
                        card.fadeOut(300, function() {
                            $(this).remove();
                            
                            // Check if there are no more favorites
                            if ($('.card').length === 0) {
                                const noFavoritesMessage = `
                                    <div class="alert alert-warning mt-3">
                                        You don't have any favorite products yet. Browse the <a href="<?php echo e(route('products_list')); ?>">products page</a> to add some!
                                    </div>
                                `;
                                $('.row:first').after(noFavoritesMessage);
                            }
                        });
                    }
                },
                error: function() {
                    alert('Error removing product from favorites. Please try again.');
                }
            });
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\WebSecApp\WebSecService\resources\views/products/favorites.blade.php ENDPATH**/ ?>