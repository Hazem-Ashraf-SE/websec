<?php $__env->startSection('title', 'Test Page'); ?>
<?php $__env->startSection('content'); ?>
<div class="row mt-2">
    <div class="col col-10">
        <h1>Products</h1>
    </div>
    <div class="col col-2">
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('add_products')): ?>
        <a href="<?php echo e(route('products_edit')); ?>" class="btn btn-success form-control">Add Product</a>
        <?php endif; ?>
    </div>
</div>

<?php if(auth()->user()->hasRole('Customer')): ?>
    <div class="alert alert-info">
        Your current credit: $<?php echo e(number_format(auth()->user()->credit, 2)); ?>

    </div>
<?php endif; ?>

<form>
    <div class="row">
        <div class="col col-sm-2">
            <input name="keywords" type="text"  class="form-control" placeholder="Search Keywords" value="<?php echo e(request()->keywords); ?>" />
        </div>
        <div class="col col-sm-2">
            <input name="min_price" type="numeric"  class="form-control" placeholder="Min Price" value="<?php echo e(request()->min_price); ?>"/>
        </div>
        <div class="col col-sm-2">
            <input name="max_price" type="numeric"  class="form-control" placeholder="Max Price" value="<?php echo e(request()->max_price); ?>"/>
        </div>
        <div class="col col-sm-2">
            <select name="order_by" class="form-select">
                <option value="" <?php echo e(request()->order_by==""?"selected":""); ?> disabled>Order By</option>
                <option value="name" <?php echo e(request()->order_by=="name"?"selected":""); ?>>Name</option>
                <option value="price" <?php echo e(request()->order_by=="price"?"selected":""); ?>>Price</option>
            </select>
        </div>
        <div class="col col-sm-2">
            <select name="order_direction" class="form-select">
                <option value="" <?php echo e(request()->order_direction==""?"selected":""); ?> disabled>Order Direction</option>
                <option value="ASC" <?php echo e(request()->order_direction=="ASC"?"selected":""); ?>>ASC</option>
                <option value="DESC" <?php echo e(request()->order_direction=="DESC"?"selected":""); ?>>DESC</option>
            </select>
        </div>
        <div class="col col-sm-1">
            <button type="submit" class="btn btn-primary">Submit</button>
        </div>
        <div class="col col-sm-1">
            <button type="reset" class="btn btn-danger">Reset</button>
        </div>
    </div>
</form>

<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="card mt-2">
        <div class="card-body">
            <div class="row">
                <div class="col col-sm-12 col-lg-4">
                    <?php if($product->photo): ?>
                        <?php
                            $photoPath = $product->photo;
                            $imageUrl = asset('uploads/' . $photoPath);
                        ?>
                        <img src="<?php echo e($imageUrl); ?>" class="img-thumbnail" alt="<?php echo e($product->name); ?>" width="100%" onerror="this.onerror=null; this.src='<?php echo e(asset('images/default-product.jpg')); ?>';">
                        <!-- Debug info: <?php echo e($product->name); ?> - <?php echo e($photoPath); ?> -->
                        <!-- Debug info: <?php echo e($product->name); ?> - <?php echo e($photoPath); ?> - <?php echo e($imageUrl); ?> -->
                    <?php else: ?>
                        <img src="<?php echo e(asset('images/default-product.jpg')); ?>" class="img-thumbnail" alt="<?php echo e($product->name); ?>" width="100%">
                    <?php endif; ?>
                </div>
                <div class="col col-sm-12 col-lg-8 mt-3">
                    <div class="row mb-2">
                        <div class="col-6">
                            <h3><?php echo e($product->name); ?></h3>
                        </div>
                        <?php if(auth()->user()->hasRole('Customer')): ?>
                        <div class="col col-2">
                            <button class="btn form-control favorite-btn" data-product-id="<?php echo e($product->id); ?>">
                                <i class="fas fa-heart favorite-icon" id="favorite-icon-<?php echo e($product->id); ?>"></i> <span id="favorite-text-<?php echo e($product->id); ?>">Favorite</span>
                            </button>
                        </div>
                        <?php endif; ?>
                        <div class="col col-2">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit_products')): ?>
                                <a href="<?php echo e(route('products_edit', $product->id)); ?>" class="btn btn-success form-control">Edit</a>
                            <?php endif; ?>
                        </div>
                        <div class="col col-2">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete_products')): ?>
                                <a href="<?php echo e(route('products_delete', $product->id)); ?>" class="btn btn-danger form-control">Delete</a>
                            <?php endif; ?>
                        </div>
                    </div>

                    <table class="table table-striped">
                        <tr><th width="20%">Name</th><td><?php echo e($product->name); ?></td></tr>
                        <tr><th>Model</th><td><?php echo e($product->model); ?></td></tr>
                        <tr><th>Code</th><td><?php echo e($product->code); ?></td></tr>
                        <tr><th>Price</th><td>$<?php echo e(number_format($product->price, 2)); ?></td></tr>
                        <?php if(auth()->user()->hasRole('Employee')): ?>
                            <tr>
                                <th>Quantity</th>
                                <td>
                                    <form action="<?php echo e(route('products.update_quantity', $product->id)); ?>" method="POST" class="d-inline">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('PUT'); ?>
                                        <div class="input-group" style="max-width: 200px;">
                                            <input type="number" name="quantity" value="<?php echo e($product->quantity); ?>" class="form-control" min="0">
                                            <button type="submit" class="btn btn-primary">Update</button>
                                        </div>
                                    </form>
                                </td>
                            </tr>
                        <?php elseif(auth()->user()->hasRole(['Admin', 'Customer'])): ?>
                            <tr>
                                <th>Quantity</th>
                                <td><?php echo e($product->quantity); ?></td>
                            </tr>
                        <?php endif; ?>
                        <tr>
                            <th>In Stock</th>
                            <td>
                                <?php if($product->quantity > 0): ?>
                                    <?php if(auth()->user()->hasRole('Customer')): ?>
                                        <?php if(auth()->user()->credit >= $product->price): ?>
                                            <form action="<?php echo e(route('products.buy', $product->id)); ?>" method="POST" style="margin-top: 5px;">
                                                <?php echo csrf_field(); ?>
                                                <button type="submit" class="btn btn-success">Buy Now</button>
                                            </form>
                                        <?php else: ?>
                                            <button class="btn btn-danger" disabled title="Insufficient credit. You need $<?php echo e(number_format($product->price - auth()->user()->credit, 2)); ?> more.">
                                                Insufficient Credit
                                            </button>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <span class="badge bg-success">In Stock</span>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <button class="btn btn-secondary" disabled>Out of Stock</button>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <tr><th>Description</th><td><?php echo e($product->description); ?></td></tr>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    $(document).ready(function() {
        // Add Font Awesome CSS if not already included
        if (!$('link[href*="font-awesome"]').length) {
            $('head').append('<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">');
        }
        
        // Style for favorite buttons
        $('.favorite-btn').each(function() {
            const productId = $(this).data('product-id');
            
            // Check if product is in favorites
            $.get(`<?php echo e(url('favorites/check')); ?>/${productId}`, function(response) {
                if (response.is_favorite) {
                    $(`#favorite-icon-${productId}`).addClass('text-danger');
                    $(`#favorite-text-${productId}`).text('Remove');
                    $(`.favorite-btn[data-product-id="${productId}"]`).addClass('btn-outline-danger');
                } else {
                    $(`#favorite-icon-${productId}`).addClass('text-secondary');
                    $(`#favorite-text-${productId}`).text('Add to Favorites');
                    $(`.favorite-btn[data-product-id="${productId}"]`).addClass('btn-outline-secondary');
                }
            });
        });
        
        // Set up CSRF token for all AJAX requests
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
            }
        });
        
        // Handle favorite button click
        $('.favorite-btn').on('click', function() {
            const productId = $(this).data('product-id');
            const button = $(this);
            const icon = $(`#favorite-icon-${productId}`);
            const text = $(`#favorite-text-${productId}`);
            
            $.ajax({
                url: `<?php echo e(url('favorites/toggle')); ?>/${productId}`,
                type: 'POST',
                success: function(response) {
                    if (response.status === 'added') {
                        icon.removeClass('text-secondary').addClass('text-danger');
                        text.text('Remove');
                        button.removeClass('btn-outline-secondary').addClass('btn-outline-danger');
                    } else {
                        icon.removeClass('text-danger').addClass('text-secondary');
                        text.text('Add to Favorites');
                        button.removeClass('btn-outline-danger').addClass('btn-outline-secondary');
                    }
                },
                error: function(xhr, status, error) {
                    console.error('Error:', xhr, status, error);
                    alert('Error updating favorites. Please try again.');
                }
            });
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\WebSecApp\WebSecService\resources\views/products/list.blade.php ENDPATH**/ ?>