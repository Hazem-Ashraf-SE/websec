

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">Insufficient Credit Errors</div>

                <div class="card-body">
                    <?php if(session('success')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('success')); ?>

                        </div>
                    <?php endif; ?>

                    <?php if(session('error')): ?>
                        <div class="alert alert-danger" role="alert">
                            <?php echo e(session('error')); ?>

                        </div>
                    <?php endif; ?>

                    <div class="table-responsive">
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>User</th>
                                    <th>Product</th>
                                    <th>Product Price</th>
                                    <th>Current Credit</th>
                                    <th>Insufficient Amount</th>
                                    <th>Error Time</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $insufficientCreditErrors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($error->user_name); ?> (<?php echo e($error->user_email); ?>)</td>
                                        <td><?php echo e($error->product_name); ?></td>
                                        <td>$<?php echo e(number_format($error->product_price, 2)); ?></td>
                                        <td>$<?php echo e(number_format($error->current_credit, 2)); ?></td>
                                        <td>$<?php echo e(number_format($error->insufficient_amount, 2)); ?></td>
                                        <td><?php echo e($error->error_time); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\WebSecApp\WebSecService\resources\views/credit/insufficient.blade.php ENDPATH**/ ?>