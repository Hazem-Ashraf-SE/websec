<?php $__env->startSection('title', 'User Profile'); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="m-4 col-sm-6">
        <table class="table table-striped">
            <tr>
                <th>Name</th><td><?php echo e($user->name); ?></td>
            </tr>
            <tr>
                <th>Email</th><td><?php echo e($user->email); ?></td>
            </tr>
            <tr>
                <th>Roles</th>
                <td>
                    <?php $__currentLoopData = $user->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <span class="badge bg-primary"><?php echo e($role->name); ?></span>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </td>
            </tr>
            <tr>
                <th>Permissions</th>
                <td>
                    <?php
                        $shownPermissions = [];
                    ?>
                    <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $permName = strtolower($permission->name);
                            if (!in_array($permName, $shownPermissions)) {
                                $shownPermissions[] = $permName;
                        ?>
                            <span class="badge bg-success"><?php echo e($permission->display_name ?? $permission->name); ?></span>
                        <?php
                            }
                        ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </td>
            </tr>
        </table>

        <div class="row">
            <div class="col col-6">
                <div>
                    <p>Your Credit: <?php echo e(auth()->user()->credit ?? 0); ?></p>
                </div>
            </div>
            <?php if(auth()->user()->hasPermissionTo('admin_users')||auth()->id()==$user->id): ?>
            <div class="col col-4">
                <a class="btn btn-primary" href='<?php echo e(route('edit_password', $user->id)); ?>'>Change Password</a>
            </div>
            <?php else: ?>
            <div class="col col-4">
            </div>
            <?php endif; ?>
            <?php if(auth()->user()->hasPermissionTo('edit_users')||auth()->id()==$user->id): ?>
            <div class="col col-2">
                <a href="<?php echo e(route('users_edit', $user->id)); ?>" class="btn btn-success form-control">Edit</a>
            </div>
            <?php endif; ?>
        </div>

        <?php if(auth()->id()==$user->id): ?>
        <div class="row mt-3">
            <div class="col-12">
                <form action="<?php echo e(route('users_delete', $user->id)); ?>" method="POST" onsubmit="return confirm('Are you sure you want to delete your account? This action cannot be undone.');">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="btn btn-danger">Delete My Account</button>
                </form>
            </div>
        </div>
        <?php endif; ?>

        <!-- Purchased Products Section -->
        <div class="row mt-4">
            <div class="col-12">
                <h3>Purchased Products</h3>
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Product Name</th>
                                <th>Model</th>
                                <th>Price</th>
                                <th>Purchase Date</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $purchasedProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($product->name); ?></td>
                                    <td><?php echo e($product->model); ?></td>
                                    <td><?php echo e($product->price); ?></td>
                                    <td><?php echo e($product->purchase_date); ?></td>
                                    <td>
                                        <form action="<?php echo e(route('return_product', ['user_id' => auth()->id(), 'product_id' => $product->id])); ?>" method="POST" onsubmit="return confirm('Are you sure you want to return this product?');">
                                            <?php echo csrf_field(); ?>
                                            <button type="submit" class="btn btn-warning btn-sm">Return</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="5" class="text-center">No products purchased yet.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\WebSec4\WebSecService\resources\views/users/profile.blade.php ENDPATH**/ ?>